#include <stdio.h>

int main(int argc, char **argv)
{
    int a, b ,c;
    scanf("%d%d%d", &a, &b, &c);
    if ((c>b) && (b>a) && (c>a))
    printf("YES\n");
    else
    printf("NO\n");
    return 0;
    return 0;
}

